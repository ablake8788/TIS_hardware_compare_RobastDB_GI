"""
Pure email message builder.
No network, no filesystem access.
Builds HTML and plain-text email bodies from AnalysisResult.
"""
from domain.models import AnalysisResult
from ports.emailer import EmailMessage


# ── Color constants (match docx_renderer palette) ────────────────────────────
GREEN  = "#C6EFCE"
YELLOW = "#FFEB9C"
RED    = "#FFC7CE"
NAVY   = "#1F4E79"
BLUE   = "#2E75B6"


def _pill(value: str) -> str:
    if value == "Yes":
        color, text = "#375623", GREEN
    elif value == "Partial":
        color, text = "#7D4A00", YELLOW
    else:
        color, text = "#9C0006", RED
    return (
        f'<span style="background:{text};color:{color};'
        f'padding:2px 10px;border-radius:12px;font-size:11px;'
        f'font-weight:600;">{value}</span>'
    )


def build_report_email(result: AnalysisResult, cfg) -> EmailMessage:
    """
    Build an EmailMessage from AnalysisResult + AppSettings.
    Pure function — no I/O, no side effects.
    """
    comp = result.competitor.name
    date = result.generated_at.strftime("%B %d, %Y %H:%M")

    # ── Summary bar ───────────────────────────────────────────────────────────
    summary_html = f"""
    <table cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin-bottom:24px;">
      <tr>
        <td style="background:#1F4E79;color:#fff;padding:8px 18px;border-radius:6px 0 0 6px;font-size:13px;font-weight:600;">
          Total: {result.total}
        </td>
        <td style="background:{GREEN};color:#375623;padding:8px 18px;font-size:13px;font-weight:600;">
          Yes: {result.yes_count}
        </td>
        <td style="background:{YELLOW};color:#7D4A00;padding:8px 18px;font-size:13px;font-weight:600;">
          Partial: {result.partial_count}
        </td>
        <td style="background:{RED};color:#9C0006;padding:8px 18px;border-radius:0 6px 6px 0;font-size:13px;font-weight:600;">
          No: {result.no_count}
        </td>
      </tr>
    </table>"""

    # ── Table rows ────────────────────────────────────────────────────────────
    rows_html = ""
    for i, row in enumerate(result.rows):
        bg = "#F8F9FA" if i % 2 == 0 else "#FFFFFF"
        rows_html += f"""
        <tr style="background:{bg};">
          <td style="padding:7px 12px;font-size:12px;font-weight:600;color:#1F4E79;border-bottom:1px solid #E9ECEF;">{row.hardware}</td>
          <td style="padding:7px 12px;font-size:12px;color:#555;border-bottom:1px solid #E9ECEF;">{row.description}</td>
          <td style="padding:7px 12px;font-size:12px;color:#555;border-bottom:1px solid #E9ECEF;">{row.companies_using or 'None'}</td>
          <td style="padding:7px 12px;text-align:center;border-bottom:1px solid #E9ECEF;">{_pill(row.titanium)}</td>
          <td style="padding:7px 12px;text-align:center;border-bottom:1px solid #E9ECEF;">{_pill(row.competitor)}</td>
        </tr>"""

    # ── Full HTML body ────────────────────────────────────────────────────────
    body_html = f"""
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"/></head>
<body style="margin:0;padding:0;background:#F1F3F5;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#F1F3F5;padding:32px 0;">
    <tr><td align="center">
      <table width="680" cellpadding="0" cellspacing="0"
             style="background:#fff;border-radius:12px;overflow:hidden;
                    box-shadow:0 2px 8px rgba(0,0,0,0.08);">

        <!-- Header -->
        <tr>
          <td style="background:{NAVY};padding:28px 32px;">
            <p style="margin:0;font-size:22px;font-weight:700;color:#fff;">
              Hardware Gap Analysis Report
            </p>
            <p style="margin:6px 0 0;font-size:13px;color:#93C5FD;">
              Titanium &nbsp;vs&nbsp; {comp} &nbsp;·&nbsp; {date}
            </p>
          </td>
        </tr>

        <!-- Summary -->
        <tr>
          <td style="padding:28px 32px 0;">
            <p style="margin:0 0 12px;font-size:14px;font-weight:600;color:{NAVY};">
              Executive summary
            </p>
            {summary_html}
          </td>
        </tr>

        <!-- Table -->
        <tr>
          <td style="padding:0 32px 28px;">
            <p style="margin:0 0 12px;font-size:14px;font-weight:600;color:{NAVY};">
              Comparison matrix
            </p>
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="border-collapse:collapse;border:1px solid #E9ECEF;border-radius:8px;overflow:hidden;">
              <thead>
                <tr style="background:{NAVY};">
                  <th style="padding:9px 12px;text-align:left;font-size:11px;color:rgba(255,255,255,0.85);font-weight:600;">Hardware</th>
                  <th style="padding:9px 12px;text-align:left;font-size:11px;color:rgba(255,255,255,0.85);font-weight:600;">Description</th>
                  <th style="padding:9px 12px;text-align:left;font-size:11px;color:rgba(255,255,255,0.85);font-weight:600;">Companies using</th>
                  <th style="padding:9px 12px;text-align:center;font-size:11px;color:rgba(255,255,255,0.85);font-weight:600;">Titanium</th>
                  <th style="padding:9px 12px;text-align:center;font-size:11px;color:rgba(255,255,255,0.85);font-weight:600;">{comp}</th>
                </tr>
              </thead>
              <tbody>
                {rows_html}
              </tbody>
            </table>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="background:#F8F9FA;padding:16px 32px;border-top:1px solid #E9ECEF;">
            <p style="margin:0;font-size:11px;color:#888;font-style:italic;">
              ⚠ AI-generated analysis — verify against official {comp} product
              documentation before use in sales or procurement decisions.
            </p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>"""

    # ── Plain text fallback ───────────────────────────────────────────────────
    body_text = f"""Hardware Gap Analysis — Titanium vs {comp}
Generated: {date}

SUMMARY
Total: {result.total} | Yes: {result.yes_count} | Partial: {result.partial_count} | No: {result.no_count}

COMPARISON
{"Hardware":<30} {"Titanium":<10} {comp:<10}
{"-"*60}
"""
    for row in result.rows:
        body_text += f"{row.hardware:<30} {row.titanium:<10} {row.competitor:<10}\n"

    body_text += f"\n⚠ AI-generated — verify before use.\n"

    # ── Assemble message ──────────────────────────────────────────────────────
    subject = f"{cfg.email.subject} — Titanium vs {comp} ({date})"

    return EmailMessage(
        subject=subject,
        body_html=body_html,
        body_text=body_text,
        to=cfg.email.to_email,
        from_addr=cfg.email.from_email,
        attachments=[result.docx_path] if result.docx_path else None,
    )
